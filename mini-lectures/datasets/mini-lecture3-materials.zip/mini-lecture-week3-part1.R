### PAC 2024
## Mini-lecture 1 - Part 1

## Topics to be covered

## 1 - Cleaning & Pivoting tables
# 1.1 - pivot_longer, pivot_wider

## 2 - Merging data 

## 3 - Creating graphs in R
# 3.1 - the ggplot2 package
# 3.2 - the three elements of a graph
#       - data, aesthetics, geometry

## Libraries we will use
library(tidyverse)

